<?php
    session_start();

    if(isset($_POST["sended"])){


        $teacher=htmlspecialchars($_POST["teacher"]);
        $manual=htmlspecialchars($_POST["manual"]);
        $namesurname=htmlspecialchars($_POST["namesurname"]);
        $phonenumber=htmlspecialchars($_POST["phonenumber"]);
        $workcount=htmlspecialchars($_POST["workcount"]);



        $_SESSION["teacher"]=$teacher;
        $_SESSION["manual"]=$manual;
        $_SESSION["namesurname"]=$namesurname;
        $_SESSION["phonenumber"]=$phonenumber;
        $_SESSION["workcount"]=$workcount;





        $errteacher="";
        $errmanual="";
        $errnamesurname="";
        $errphonenumber="";
        $errworkcount="";



        $error=false;


        if($phonenumber==""){
            $errphonenumber="The block phone number is empty!";
            $error=true;
        }

        if($workcount==""){
            $errworkcount="The block is empty!";
            $error=true;
        }

        if($namesurname==""){
            $errnamesurname="The block name surname is empty!";
            $error=true;
        }


        if($teacher==""){
            $errteacher="The block is empty!";
            $error=true;
        }


        if($manual==""){
            $errmanual="The block is empty!";
            $error=true;
        }


        if($namesurname > 6 && $namesurname < 22){
            $errnamesurname="The word of count min is 6";
            $error=true;
        }


        if($phonenumber > 9 && $phonenumber < 12){
            $errphonenumber="The word of count min is 9";
            $error=true;
        }

        if($workcount >= 1 && $workcount <= 10){
            $errworkcount="The number count min is 1";
            $error=true;
        }

        










    }


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="qaxvarum.css">
</head>
<body>



    <form action="" method="post" >
        
        <nav class="nav">
            <ul class="ul" name="ul">
                <li name="li1" class="li1">
                    <a class="a1 a1hed" name="a1" href="http://localhost/projects/carschool/himnakan/patet/patet.php">Հիմնական</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/dasaxosner/dasaxosner.php">Դասախոսներ</a>
                </li>
                <li name="li1" class="li1 ">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/hrahang/hrah.html">Հրահանգիչներ</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/usanoxner/us.html">Ուսանողներ</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/daser/daser.html">Դասընթացներ</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/arxiv/arxiv.html">Արխիվ</a>
                </li>
            </ul>
        </nav>
    
    
    
        <h1 class="regname">Գրանցումներ</h1>
    
        <div class="btnheader">
            <div class="divitem">
                <li>
                    <a class="a1  iteama1" href="http://localhost/projects/carschool/himnakan/patet/patet.php">Փաթեթներ </a>
                </li>
            </div>
            <div class="divitem">
                <li>
                    <a class="a1 iteama1" href="http://localhost/projects/carschool/anhatakan/anhat.php">Անհատական</a>
                </li>
            </div>
            <div class="divitem">
                <li>
                    <a class="a1 a1hed iteama1" href="http://localhost/projects/carschool/qaxvarum/qaxvarum.php">Քաղ․Վարում</a>
                </li>
            </div>
            <div class="divitem">
                <li>
                    <a class="a1 iteama1" href="">Քնն․Երթուղի</a>
                </li>
            </div>
        </div>
    
    
    
        <div class="divheader">
            <div class="contitem1">         
                <button class="btnsend" name="sended" type="submit">Գրանցել+</button>
            </div>
            <br>
            <br>
            <br>
            <br>
    
            <div class="contitem2">
                <div class="container">
                    <label class="lab1" for="">
                        Հրահանգիչ
                        <br>
                        <select class="sel1" name="teacher" id="">
                            <option value="lorem">Ընտրել</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
        
        
                        </select>
                        <br>
                        <span><?=@$errteacher?></span>
    
                    </label>

                    
    
                    <label class="lab1" for="">
                        Փոխանցման տուփ
                        <br>
                        <select name="manual" class="sel1">
                            <option value="" class="opt">Ընտրել</option>
                            <option value="mech" class="opt1">Մեխ․</option>
                            <option value="avto" class="opt1">Ավտո․</option>
                        </select>
                        <br>
                        <span><?=@$errmanual?></span>
    
                    </label>
    
                        
                        <label for="" class="lab1">
                            Անուն Ազգանուն
                            <br>
                            <input name="namesurname" class="inp1" type="text">
                            <br>
                            <span><?=@$errnamesurname?></span>
    
                        </label>
                        
                        <label for="" class="lab1">
                            Հեռախոսահամար
                            <br>
                            <input name="phonenumber" class="inp1" type="text">
                            <br>
                            <span><?=@$errphonenumber?></span>
                        </label>



                        <label for="" class="lab1">
                            Դասաքանակ
                            <br>
                            <input name="workcount" class="inp1" type="number">
                            <br>
                            <span><?=@$errworkcount?></span>
                        </label>
    
                        <br>
                        <br>
    
                </div>
    
    
    
    
            </div>
    
            <span>
    
                <div class="btndiv">
                    <button name="btnamd1" value="buy" class="btn1">ՎՃԱՐՎԱԾ</button>
                    <button name="btnamd2" value="apa" class="btn2">ԱՊԱՌԻԿ</button>
                    <button name="btnamd3" value="notbuy" class="btn3">ՉՎՃԱՐՎԱԾ</button>
                </div>
    
            </span>
     
    
        </div>

    </form>

    

    
</body>
</html>