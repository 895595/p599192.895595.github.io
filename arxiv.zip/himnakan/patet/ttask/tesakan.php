<?php
    session_start();

    if(isset($_POST["sended"])){

        $cerekereko=htmlspecialchars($_POST["cerekereko"]);

        $teacher=htmlspecialchars($_POST["teacher"]);
        $namesurname=htmlspecialchars($_POST["namesurname"]);
        $phonenumber=htmlspecialchars($_POST["phonenumber"]);



        $_SESSION["cerekereko"]=$cerekereko;

        $_SESSION["teacher"]=$teacher;
        $_SESSION["namesurname"]=$namesurname;
        $_SESSION["phonenumber"]=$phonenumber;


        $errcerekereko="";

        $errteacher="";
        $errmanual="";
        $errnamesurname="";
        $errphonenumber="";


        $error=false;


        if($cerekereko==""){
            $errcerekereko="The block is empty!";
            $error=true;
        }

        if($phonenumber==""){
            $errphonenumber="The block phone number is empty!";
            $error=true;
        }


        if($namesurname==""){
            $errnamesurname="The block name surname is empty!";
            $error=true;
        }


        if($teacher==""){
            $errteacher="The block is empty!";
            $error=true;
        }




        if($namesurname > 6 && $namesurname < 22){
            $errnamesurname="The word of count min is 6";
            $error=true;
        }


        if($phonenumber > 9 && $phonenumber < 12){
            $errphonenumber="The word of count min is 9";
            $error=true;
        }

        










    }


?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tesakan</title>
    <link rel="stylesheet" href="tesakan.css">
</head>
<body>



    <form action="" method="post" enctype="multipart/form-data">
        
        <nav class="nav">
            <ul class="ul" name="ul">
                <li name="li1" class="li1">
                    <a class="a1 a1hed" name="a1" href="http://localhost/projects/carschool/himnakan/patet/patet.php">Հիմնական</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/dasaxosner/dasaxosner.php">Դասախոսներ</a>
                </li>
                <li name="li1" class="li1 ">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/hrahang/hrah.html">Հրահանգիչներ</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/usanoxner/us.html">Ուսանողներ</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/daser/daser.html">Դասընթացներ</a>
                </li>
                <li name="li1" class="li1">
                    <a class="a1" name="a1" href="http://localhost/projects/carschool/arxiv/arxiv.html">Արխիվ</a>
                </li>
            </ul>
        </nav>
    
    
    
        <h1 class="regname">Գրանցումներ</h1>
    
        <div class="btnheader">
            <div class="divitem">
                <li>
                    <a class="a1 a1hed iteama1" href="http://localhost/projects/carschool/himnakan/patet/patet.php">Փաթեթներ </a>
                </li>
            </div>
            <div class="divitem">
                <li>
                    <a class="a1 iteama1" href="http://localhost/projects/carschool/anhatakan/anhat.php">Անհատական</a>
                </li>
            </div>
            <div class="divitem">
                <li>
                    <a class="a1 iteama1" href="http://localhost/projects/carschool/qaxvarum/qaxvarum.php">Քաղ․Վարում</a>
                </li>
            </div>
            <div class="divitem">
                <li>
                    <a class="a1 iteama1" href="http://localhost/projects/carschool/himnakan/home.html">Քնն․Երթուղի</a>
                </li>
            </div>
        </div>
    
    
    
        <div class="divheader">
            <div class="contitem1">
                <br>
                <label class="lab1" for="">
                    Ցերեկային
                    <input class="" name="cerekereko" type="radio">
                    <span><?=@$errcerekereko?></span>
                </label>
                <tr>|</tr>
                <label class="lab1" for="">
                    Երեկոյան
                    <input class="" name="cerekereko" type="radio">
                    <span><?=@$errcerekereko?></span>
    
                </label>
                <br>
                <br>
    
                <label class="lab1" for="">
                    
                    <!-- <input class="" name="tabletask" type="radio"> -->
                    <a href="http://localhost/projects/carschool/himnakan/patet/ttask/tesakan.php" class="ttask a1href" name="tabletask">Տեսական</a>
                    <span><?=@$errtabletask?></span>
                </label>
                <tr>|</tr>
                <label class="lab1" for="">
                    
                    <!-- <input class="" name="tabletask" type="radio"> -->
                    <a href="http://localhost/projects/carschool/himnakan/patet/patet.php" class="ttask" name="tabletask" >Էկոնոմ</a>
                    <span><?=@$errtabletask?></span>
    
                </label>
                <tr>|</tr>
                <label class="lab1" for="">
                    
                    <!-- <input class="" name="tabletask" type="radio"> -->
                    <a href="http://localhost/projects/carschool/himnakan/patet/ttask/standart.php" class="ttask" name="tabletask" >Ստանդարտ</a>

                    <span><?=@$errtabletask?></span>
                </label>
    
                <button class="btnsend" name="sended" type="submit">Գրանցել+</button>
    
    
                
    
            </div>
            <br>
            <br>
            <br>
            <br>
    
            <div class="contitem2">
                <div class="container">
                    <label class="lab1" for="">
                        Դասախոս
                        <br>
                        <select class="sel1" name="teacher" id="">
                            <option value="lorem">Ընտրել</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
                            <option value="lorem">lorem</option>
        
        
                        </select>
                        <br>
                        <span><?=@$errteacher?></span>
    
                    </label>

                    
    
                    <!-- <label class="lab1" for="">
                        Փոխանցման տուփ
                        <br>
                        <select name="manual" class="sel1">
                            <option value="" class="opt">Ընտրել</option>
                            <option value="mech" class="opt1">Մեխ․</option>
                            <option value="avto" class="opt1">Ավտո․</option>
                        </select>
                        <br>
                        <span><?=@$errmanual?></span>
    
                    </label> -->
    
                        
                        <label for="" class="lab1">
                            Անուն Ազգանուն
                            <br>
                            <input name="namesurname" class="inp1" type="text">
                            <br>
                            <span><?=@$errnamesurname?></span>
    
                        </label>
                        
                        <label for="" class="lab1">
                            Հեռախոսահամար
                            <br>
                            <input name="phonenumber" class="inp1" type="text">
                            <br>
                            <span><?=@$errphonenumber?></span>
                        </label>
    
                        <br>
                        <br>
    
                </div>
    
    
    
    
            </div>
    
            <span>
    
                <div class="btndiv">
                    <button name="btnamd1" value="buy" class="btn1">ՎՃԱՐՎԱԾ</button>
                    <button name="btnamd2" value="apa" class="btn2">ԱՊԱՌԻԿ</button>
                    <button name="btnamd3" value="notbuy" class="btn3">ՉՎՃԱՐՎԱԾ</button>
                </div>
    
            </span>
     
    
        </div>

    </form>

    

    
</body>
</html>