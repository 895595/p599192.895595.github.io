<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="home.css">
</head>
<body>


    <nav class="nav">
        <ul class="ul" name="ul">
            <li name="li1" class="li1">
                <a class="a1 a1hed" name="a1" href="http://localhost/projects/carschool/himnakan/patet/patet.php">Հիմնական</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1" name="a1" href="http://localhost/projects/carschool/dasaxosner/dasaxosner.php">Դասախոսներ</a>
            </li>
            <li name="li1" class="li1 ">
                <a class="a1" name="a1" href="http://localhost/projects/carschool/hrahang/hrah.html">Հրահանգիչներ</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1" name="a1" href="http://localhost/projects/carschool/usanoxner/us.html">Ուսանողներ</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1" name="a1" href="http://localhost/projects/carschool/daser/daser.html">Դասընթացներ</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1" name="a1" href="http://localhost/projects/carschool/arxiv/arxiv.html">Արխիվ</a>
            </li>
        </ul>
    </nav>



    <h1 class="regname">Գրանցումներ</h1>

    <div class="btnheader">
        <div class="divitem">
            <li>
                <a class="a1 iteama1" href="http://localhost/projects/carschool/himnakan/patet/patet.php">Փաթեթներ </a>
            </li>
        </div>
        <div class="divitem">
            <li>
                <a class="a1 iteama1" href="http://localhost/projects/carschool/anhatakan/anhat.php">Անհատական</a>
            </li>
        </div>
        <div class="divitem">
            <li>
                <a class="a1 iteama1" href="http://localhost/projects/carschool/qaxvarum/qaxvarum.php">Քաղ․Վարում</a>
            </li>
        </div>
        <div class="divitem">
            <li>
                <a class="a1 iteama1" href="">Քնն․Երթուղի</a>
            </li>
        </div>
    </div>





    
</body>
</html>