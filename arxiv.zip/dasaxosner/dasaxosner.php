<?php
    $db=mysqli_connect("localhost", "root", "", "admintest");



    if(isset($_POST["sendadd"])){
        $namesurname=$_POST["namesurname"];
        $phonenumber=$_POST["phonenumber"];
        $datatime=$_POST["datatime"];


        $errornamesurname="";
        $errorphonenumber="";
        $errordatatime="";

        $error=false;        





        $kap="INSERT INTO crud VALUES (null,'$namesurname','$phonenumber','$datatime')";
        if(mysqli_query($db,$kap)){
            echo '<script>alert("User registered successfully");</script>';
            header('location:dasaxosner.php');
        }else{
            mysqli_error($db);
        }


       


    }




?>













<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="dasaxosner.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Edu+SA+Beginner&family=Kanit:wght@200&family=Montserrat:wght@300&family=Noto+Serif:wght@300&family=Titillium+Web:wght@200&display=swap" rel="stylesheet">
</head>
<body>

    <nav class="nav">
        <ul class="ul" name="ul">
            <li name="li1" class="li1">
                <a class="a1 " name="a1" href="http://localhost/projects/carschool/himnakan/patet/patet.php">Հիմնական</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1 a1hed" name="a1" href="http://localhost/projects/carschool/dasaxosner/dasaxosner.php">Դասախոսներ</a>
            </li>
            <li name="li1" class="li1 ">
                <a class="a1" name="a1" href="http://localhost/projects/carschool/hrahang/hrah.html">Հրահանգիչներ</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1 " name="a1" href="http://localhost/projects/carschool/usanoxner/us.html">Ուսանողներ</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1 " name="a1" href="http://localhost/projects/carschool/daser/daser.html">Դասընթացներ</a>
            </li>
            <li name="li1" class="li1">
                <a class="a1" name="a1" href="http://localhost/projects/carschool/arxiv/arxiv.html">Արխիվ</a>
            </li>
        </ul>
    </nav>

    <form action="" method="post">
                <div class="dasaxosner">
                    <h1>Դասախոսներ</h1>
                </div>
        <div class="main">
                <br>
                <br>

                <br>
                <div class="divinp">
                    <div class="divinp2">
                        <input placeholder="Անուն Ազգանուն" type="text" class="btnadd" name="namesurname">
                        <span><?=@$errornamesurname?></span>
                        <input placeholder="Հեռախոսահամար" type="text" class="btnadd" name="phonenumber">
                        <span><?=@$errorphonenumber?></span>
                        <input placeholder="Օր՝ 01․01․2023" type="text" class="btnadd" name="datatime">
                        <span><?=@$errordatatime?></span>
                        <br>
                        <br>
                        <button class="btnedit" name="sendadd">Ավելացնել</button>
                    </div>
                </div>
                

                <br>

            <div class="container">
                <div class="divmain2">
                    <br>
                    <?php
                        $i = 0;
                        $qry = "SELECT * from crud";
                        $run = $db -> query($qry);
                        if($run -> num_rows > 0){
                            while($row = $run -> fetch_assoc()){
                                $id = $row['id'];
                    ?>
                    <div class="divnames">
                        <td>
                            <!-- <a class="aa1 aa2"><?php echo $i++; ?> </a>| -->
                            <a class="aa1"><?php echo $row['namesurname'] ?> |</a>
                            <a class="aa1"><?php echo $row['phonenumber'] ?> |</a>
                            <a class="aa1"><?php echo $row['datatime'] ?> |</a>



                            <td class="td">
                                <a class="btndel" href="delete.php?id=<?php echo $id; ?>" onclick="return confirm('Դուք համոզված եք՞, որ ցանկանում եք Հեռացնել՞')">Հեռացնել</a> -
                                <a class="btned" href="edit.php?id=<?php echo $id; ?>" onclick="return confirm('Դուք համոզված եք՞, որ ցանկանում եք Փոփոխել՞')">Փոփոխել</a>
                                
                            
                            </td>
                            

                        </td>

                    </div>
                    <?php 

                            }
                        }

                    ?>
                </div>
                    
                    
                </div>

        </div>
    </form>


   
    
</body>
</html>