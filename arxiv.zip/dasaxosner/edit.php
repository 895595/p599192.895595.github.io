<?php
$db = mysqli_connect("localhost","root","", "admintest");
if(!$db){
    die('error in db'.mysqli_query($db));
}else{
    $id = $_GET['id'];
    $qry = "SELECT * from crud WHERE id = $id";
    $run = $db -> query($qry);
    if($run -> num_rows > 0){
        while($row = $run -> fetch_assoc()){
            $namesurname = $row['namesurname'];
            $phonenumber = $row['phonenumber'];
            $datatime = $row['datatime'];


        }
    }

}



?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="edit.css">
</head>
<body>

    <form action="" method="post">
        <h1 class="h1hed">Փոփոխում</h1>
            <div class="divinp">
                <input class="input1" value="<?php echo $namesurname; ?>" type="text" class="btnadd" name="namesurname">
                <input class="input1" value="<?php echo $phonenumber; ?>" type="tel" class="btnadd" name="phonenumber">
                <input class="input1" value="<?php echo $datatime; ?>" type="text" class="btnadd" name="datatime">
                <br>
                <button class="btnedit" name="update">Փոփոխել</button>
            </div>
    </form>
    
</body>
</html>


<?php

if(isset($_POST["update"])){
    $namesurname=$_POST['namesurname'];
    $phonenumber=$_POST['phonenumber'];
    $datatime=$_POST['datatime'];


    $qry = "update crud set namesurname='$namesurname', phonenumber='$phonenumber', datatime='$datatime' where id = $id";
    if(mysqli_query($db,$qry)){
        header('location:dasaxosner.php');
    }else{
        mysqli_error($db);
    }

}



?>