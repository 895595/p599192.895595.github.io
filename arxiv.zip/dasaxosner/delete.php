<?php
$db = mysqli_connect("localhost","root","", "admintest");
if(!$db){
    die('error in db'.mysqli_query($db));
}

$id = $_GET['id'];

$qry = "delete from crud where id = $id";

if(mysqli_query($db, $qry)){
    header('location:dasaxosner.php');
}else{
    echo mysqli_error($db);
}



?>