<?php

    session_start();

    if(isset($_POST["send"])){
        $login=htmlspecialchars($_POST["login"]);
        $password=htmlspecialchars($_POST["pass"]);

        $_SESSION["login"]=$login;
        $_SESSION["password"]=$password;

        $errorlogin="";
        $errorpassword="";

        $error=false;



        if($login==""){
            $errorlogin="Login block is empty!";
            $error=true;
        }

        if($password==""){
            $errorpassword="Password block is empty!";
            $error=true;
        }


        if($password=="1234" && $login=="1234"){
            echo("Login succesfully");
            $error=false;
                
        }else{
            echo("Login failed");
            $error=true;
    
        }


        if($error==false){
            $kap=mysqli_connect("127.0.0.1:3306","root","","p599192_alex");
            mysqli_query($kap,"SET NAMES 'utf8' ");
            mysqli_query($kap,"INSERT INTO test_admin(id,login,password) VALUES ('$login','$password');");
            header("location:himnakan/patet/patet.php");
        }

    }





?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Car School</title>
    <link rel="stylesheet" href="index.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-4">
        <h1 class="h1log">Login Page</h1>
        <form action="" enctype="multipart/form-data" method="post">
            <div class="header">
                <div class="backheader">
                    <input type="text" name="login" class="form-control" id="login" placeholder="Enter a Login">
                    <span class="errspan"><?=@$errorlogin?></span>
                    <br>
                    <input type="password" name="pass" class="form-control" id="pass" placeholder="Enter a Password">
                    <span class="errspan"><?=@$errorpassword?></span>
                    <br>
                    <button class="btn btn-success" name="send">Login</button>
                </div>
            </div>



        </form>
    </div>



</body>
</html>